#include <stdio.h>
#include 'cs3743p1.h'

/*int hashCreate(char szFileNm[], HashHeader *pHashHeader)
 *This function creates a hash file containing only the HashHeader record.
 *	If the file already exists, return RC_FILE_EXISTS	 
 *	Create the binary file by opening it.
 *	Write the HashHeader record to the file at RBN 0.
 *	fclose the file.
 *	return RC_OK.
 *
 *typedef struct
 *	{
 *    FILE *pFile;            // FILE pointer to the hash file
 *    HashHeader hashHeader;  // the header record contents for a hash file
 *  } HashFile;
 *
 */
int hashCreate(char szFileNm[], HashHeader *pHashHeader){
	HashFile *pHashFile;
	int pWrite;
	pHashFile->pFile  = fopen(szFileNm, "rb");	
	if ((pHashFile->pFile != NULL))
    {
        fclose(pHashFile->pFile);
        return RC_FILE_EXISTS;
    }
	//Open and create Binary file
	pHashFile->pFile = fopen(szFileNm, "wb+");
	//fwrite (pHashHeader, sizeof(HashHeader), 1L, pHashFile->pFile ); pHashHeader -> iRecSize instead of sizeof hashheader?
	
	pHashHeader->iMaxOvRBN = pHashHeader->iMaxPrimary; //set iMaxOvRbn to iMaxPrimary
	pWrite = fwrite(pHashHeader, pHashHeader->iRecSize, 1L, pHashFile->pFile);
	fclose(pHashFile->pFile);
	return RC_OK;
}

/*int hashOpen(char szFileNm[], HashFile *pHashFile)
 *This function opens an existing hash file which must contain a HashHeader record, and sets the pHashFile->pFile. 
 *It returns the HashHeader record by setting pHashFile->hashHeader..
 *Use fopen to open the file.  If it doesn't exist, return RC_FILE_NOT_FOUND.
 *Use fread to read the HashHeader record and return it through the parameter.  If the read fails, return RC_HEADER_NOT_FOUND.
 *Do NOT close the file since the other functions will assume that it is open.
 typedef struct
{
    FILE *pFile;            // FILE pointer to the hash file set me
    HashHeader hashHeader;  // the header record contents for a hash file 
} HashFile;
 */
int hashOpen(char szFileNm[], HashFile *pHashFile){
	pHashFile->pFile = fopen(szFileNm, "rb+");

    if (pHashFile->pFile == NULL)
        return RC_FILE_NOT_FOUND;
    
    if (fread(&(pHashFile->hashHeader), sizeof(HashHeader), 1L, pHashFile->pFile) == 0)
        return RC_HEADER_NOT_FOUND;

    return RC_OK;
}

/*int readRec(HashFile *pHashFile, int iRBN, void *pRecord)
 *This function reads a record at the specified RBN in the specified file. 
 *Determine the RBA based on iRBN and pHashFile->hashHeader.iRecSize.
 *Use fseek to position the file in that location.
 *Use fread to read that record and return it through pRecord.
 *If the location is not found, return RC_LOC_NOT_FOUND.  Otherwise, return RC_OK.
 *Note: if the location is found, that does NOT imply that a book was written to that location.  Why?
*/
int readRec(HashFile *pHashFile, int iRBN, void *pRecord){
	int RecSeek = fseek(pHashFile->pFile, iRBN, SEEK_SET);
	assert(rcFseek == 0);

	int iReadRec = fread(&pRecord, sizeof(&pRecord), 1L, pHashFile->pFile);

	if (iReadRec == 1){
		return RC_OK;
	}
  return RC_LOC_NOT_FOUND;
}

/*int writeRec(HashFile *pHashFile, int iRBN, void *pRecord)
This function writes a record to the specified RBN in the specified file. 
•	Determine the RBA based on iRBN and pHashFile->hashHeader.iRecSize.
•	Use fseek to position the file in that location.
•	Use fwrite to write that record to the file.
•	If the fwrite fails, return RC_LOC_NOT_WRITTEN.  Otherwise, return RC_OK.
*/
int writeRec(HashFile *pHashFile, int iRBN, void *pRecord){
	int dRba = 0;
    dRba = iRBN * pHashFile->hashHeader.iRecSize;

    fseek(pHashFile->pFile, lRBA, SEEK_SET);

    if (fwrite(pRecord, pHashFile->hashHeader.iRecSize, 1L, pHashFile->pFile) != 1)
        return RC_LOC_NOT_WRITTEN;

    return RC_OK;
}

/*int insertBook(HashFile *pHashFile, Book *pBook)
*This function inserts a book into the specified file.
•	Determine the RBN using the driver's hash function.
•	Use readRec to read a record at that RBN.  
•	If that location doesn't exist or the record at that location has a szBookId[0] == '\0':
o	Write the new  book record (using pBook) at that location using writeRec.
•	If that record exists and that book's szBookId matches pBook->szBookId, return RC_REC_EXISTS.  (Do not update it.)
•	Otherwise, return RC_SYNONYM.  Note that in program #2, we will actually insert synonyms.

*/
int insertBook(HashFile *pHashFile, Book *pBook){
	
	
}

/*int readBook(HashFile *pHashFile, Book *pBook, int *piRBN)
This function reads the specified book by its szBookId.
•	Since pBook->szBookId was provided, determine the RBN using the driver's hash function. 
•	Be able to return that RBN via the third parameter. In Pgm#2, the returned RBN might not be the hashed RBN.
•	Use readRec to read the record at that RBN. Be careful to not initially overwrite pBook.
•	If the book at that location matches the specified pBook->szBookId, return the book via pBook and return RC_OK.
•	Otherwise, return RC_REC_NOT_FOUND 
*/
int readBook(HashFile *pHashFile, Book *pBook, int *piRBN){
	
	
}