int findFreeFrames(unsigned int *freeFrames , unsigned int frames);
int getVictimLRU(unsigned int *LRUCount, unsigned int frames);