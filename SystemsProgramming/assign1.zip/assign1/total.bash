#!/bin/bash

echo "Total course records: "

find .  -name "*.crs" -exec ls -al {} \;