#! /bin/bash
# assign2

date=$(date +”%m/%d/%Y”)

sed -f assign2.sed "$1"